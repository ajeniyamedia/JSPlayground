export const DID_UPDATE_CODE = 'did_update_code';
