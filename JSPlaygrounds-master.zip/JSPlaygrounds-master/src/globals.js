import _ from 'lodash';
import React, { Component } from 'react';

_.extend(window, { _, React, Component });
