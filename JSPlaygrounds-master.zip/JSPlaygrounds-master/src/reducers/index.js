import { combineReducers } from 'redux';
import code from 'reducers/code_reducer';

const rootReducer = combineReducers({
  code
});

export default rootReducer;
